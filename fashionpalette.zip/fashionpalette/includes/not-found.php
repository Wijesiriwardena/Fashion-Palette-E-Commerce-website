<div class="p-5" style='height: 600px'>
    <div class="text-center mt-5">
        <img src="https://img.icons8.com/?size=100&id=Dr6ZRXLR8tfR&format=png&color=000000"
             alt="404 not found">
    </div>
    <h2 class='text-center mt-3' style="font-weight: 700">NOT FOUND</h2>
</div>
