<?php
global $pro_dir, $user_id, $back_route, $img_src, $img_placeholder;

$queries = array();
parse_str($_SERVER['QUERY_STRING'], $queries);

// Check product id available in the query params
if (!isset($queries['product_id'])) {
    header('Location: ' . $back_route);
    exit();
}

$cart_route = $pro_dir . 'cart';
$products_route = $pro_dir . 'product';
$customize_route = $pro_dir . 'product/customize?product_id=';

$product_sizes = get_product_sizes();
$colors = get_color_options();

$product_id = intval($queries['product_id']);

fetch_product();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // User needs to be logged in inorder to add item to cart.
    if (!is_logged_in()) {
        header('Location: ' . $pro_dir . 'login');
        exit();
    }

    if (isset($_POST['add-to-cart'])) {
        add_to_cart();
    }

    if (isset($_POST['add-to-favourite'])) {
        add_to_favourite();
    }

}

function fetch_product()
{
    global $data, $product_id, $img_src, $img_placeholder;

    $conn = connect_db();
    $sql = "SELECT p.product_id, p.product_name, p.description, p.price, p.discount, p.stock, p.image, 
            p.favourite_count, g.gender_name as gender_name, b.brand_name as brand_name, 
            b.description as brand_description, p.category_id  
        FROM product as p 
        LEFT JOIN gender as g on p.gender_id = g.gender_id
        LEFT JOIN category as c on p.category_id = c.category_id
        LEFT JOIN brand as b on p.brand_id = b.brand_id
        WHERE p.product_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $product_id);

    if ($stmt->execute()) {
        $data = $stmt->get_result()->fetch_assoc();
        $img_src = isset($data['image']) ? 'data:image/*;base64,' . base64_encode($data['image']) : $img_placeholder;
    } else {
        $_SESSION['form_data'] = ['error' => "Error while retrieving product: " . $stmt->error];
    }

    $stmt->close();
    $conn->close();
}

function add_to_cart()
{
    global $user_id, $product_id, $cart_route;

    $conn = connect_db();

    $size_id = htmlspecialchars($_POST['size_id']);
    $color_id = htmlspecialchars($_POST['color_id']);
    $quantity = 1;

    // Start transaction
    $conn->begin_transaction();
    try {
        // Insert item spec
        $sql = "INSERT INTO item_spec (color_id, size_id) VALUES (?, ?)";
        $stmt_item_spec = $conn->prepare($sql);
        $stmt_item_spec->bind_param("ii", $color_id, $size_id);

        if (!$stmt_item_spec->execute()) {
            throw new Exception("Item spec insert failed: " . $stmt_item_spec->error);
        }

        // Get the contact ID of the inserted contact (for both shipping and billing, assuming they are the same)
        $item_spec_id = $stmt_item_spec->insert_id;

        // Insert product into cart
        $sql = "INSERT INTO cart_item (user_id, product_id, item_spec_id, quantity) VALUES (?, ?, ?, ?)";
        $stmt_cart = $conn->prepare($sql);
        $stmt_cart->bind_param("iiii", $user_id, $product_id, $item_spec_id, $quantity);

        if (!$stmt_cart->execute()) {
            throw new Exception("Error while adding item to cart: " . $stmt_item_spec->error);
        }

        $stmt_item_spec->close();
        // Commit the transaction
        $conn->commit();
        $conn->close();

        // Redirect to cart page
        $_SESSION["form_data"] = ['message' => 'Product added to cart successfully'];
        header('Location: ' . $cart_route);
        exit();
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION["form_data"] = [
            "error" => $e->getMessage(),
            "size_id" => $_POST["size_id"],
            "color_id" => $_POST["color_id"]
        ];
        // Redirect back to the form page
        header("Location: " . $_SERVER["REQUEST_URI"]);
        // Close the database connection
        $conn->close();
        exit();
    }
}

function add_to_favourite()
{
    global $user_id, $product_id;

    $conn = connect_db();

    // Insert product into favourite
    $sql = "SELECT user_id, product_id FROM `favourite` WHERE user_id = ? AND product_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $user_id, $product_id);

    if (!$stmt->execute()) {
        $_SESSION["form_data"] = ['message' => 'Product added to favourites successfully'];
        $stmt->close();
        $conn->close();

        // Redirect back
        header("Location: " . $_SERVER["REQUEST_URI"]);
        exit();
    }

    $data = $stmt->get_result()->fetch_assoc();
    if ($data) {
        $_SESSION["form_data"] = ['warn' => 'Product already available in favourites'];
        $stmt->close();
        $conn->close();

        // Redirect back
        header("Location: " . $_SERVER["REQUEST_URI"]);
        exit();
    }


    // Start transaction
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("INSERT INTO `favourite` (user_id, product_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $user_id, $product_id);

        if (!$stmt->execute()) {
            throw new Exception("Error while adding product to favourites: " . $stmt->error);
        }

        $stmt = $conn->prepare("UPDATE `product` SET favourite_count = favourite_count + 1 WHERE product_id = ?");
        $stmt->bind_param("i", $product_id);

        if (!$stmt->execute()) {
            throw new Exception("Error while updating product favourite count: " . $stmt->error);
        }

        // Commit the transaction
        $conn->commit();
        $_SESSION["form_data"] = ["message" => 'Item added to favourites successfully'];
    } catch (Exception $e) {
        $_SESSION["form_data"] = ["error" => $e->getMessage()];
    }

    $stmt->close();
    $conn->close();

    // Redirect back
    header("Location: " . $_SERVER["REQUEST_URI"]);
    exit();
}

if (isset($data)) {
    $out_of_stock = $data['stock'] <= 0; ?>
    <div class="container custom-container custom-container-lg p-5">
        <div class="row">
            <div class="col-lg-7 col-md-12 img-container">
                <img alt="" src="<?php echo $img_src ?>" style="max-height: 580px">
                <div class="image-card-favourite-container">
                    <span class="badge favourite-badge">
                        <i class="fa-solid fa-heart"></i> <?php
                        echo isset($data["favourite_count"]) && $data["favourite_count"] > 0 ?
                            $data["favourite_count"] : 0 ?>
                    </span>
                </div>
            </div>
            <div class="col-lg-5 col-md-12">
                <form class="custom-form" action="" method="POST">
                    <div class="form-title product-title text-content">
                        <?php echo $data['product_name'] ?>
                    </div>
                    <div class="product-brand text-content text-center mb-3">
                        <?php echo $data['gender_name'] . ' | ' . $data['brand_name'] ?>
                    </div>
                    <div class="description text-content mb-4">
                        <?php echo $data['description'] ?>
                    </div>
                    <div class="product-flex-row mb-2">
                        <div>
                            <div class="product-price text-content">
                                <?php echo 'Now $' . $data['price'] ?>
                            </div>
                            <?php
                            if (isset($data['discount']) && $data['discount'] > 0): ?>
                                <div class="product-discount text-content">
                                    Was $<?php echo ($data['price'] * ($data['discount'] + 100)) / 100.0 ?>
                                    (-<?php echo $data['discount'] ?>%)
                                </div>
                            <?php endif; ?>
                        </div>
                        <div>
                            <?php if ($data["category_id"] == 3 || $data["category_id"] == 5): ?>
                                <a class="form-link" href="<?php echo $customize_route . $data['product_id'] ?>">
                                    customize
                                </a>
                            <?php endif;
                            if ($out_of_stock): ?>
                                <div class="out-of-stock text-content float-right">
                                    Out of stock
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group required mt-1">
                        <div class="input-wrapper">
                            <label for="color_id" class="form-label control-label">Color</label>
                            <select class="custom-select" id="color_id" name="color_id">
                                <?php foreach ($colors as $color): ?>
                                    <option value="<?php echo $color['color_id'] ?>">
                                        <?php echo $color['color_name'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group required">
                        <div class="input-wrapper">
                            <label for="size_id" class="form-label control-label">Size</label>
                            <select class="custom-select" id="size_id" name="size_id">
                                <?php foreach ($product_sizes as $size): ?>
                                    <option value="<?php echo $size['size_id'] ?>">
                                        <?php echo $size['size_name'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="d-flex">
                        <button style="width: 88%" type="submit" name="add-to-cart"
                                class="btn btn-sm btn-custom-secondary my-2 mr-1"
                            <?php if ($out_of_stock) {
                                echo 'disabled';
                            } ?>>
                            Add to cart
                        </button>
                        <button style="width: 12%" name="add-to-favourite"
                                type="submit" class="btn btn-sm btn-custom-secondary my-2">
                            <i class="fa fa-heart"></i>
                        </button>
                    </div>
                    <div class="d-flex my-2" style="justify-content: space-between">
                        <div class="text-content">
                            <b>Brand:</b> <?php echo $data['brand_name'] ?>
                        </div>
                    </div>
                    <div class="description text-content mb-3">
                        <?php echo $data['brand_description'] ?>
                    </div>
                </form>
                <div class="delivery-info description text-content text-center">
                    <i class="fa-solid fa-truck pr-2"></i>Free delivery on qualifying orders.
                    <div class="form-links text-content mt-3" style="font-size: 10px">
                        <a href="#">View our delivery and return policy</a> |
                        <a href="#">Report a legal concern</a></div>
                </div>
                <div class="form-link text-content my-3">
                    <a class="form-link" href="<?php echo $products_route ?>">Back to products</a>
                </div>
            </div>
        </div>
    </div>
<?php } else {
    include_once __DIR__ . '/../includes/not-found.php';
}
