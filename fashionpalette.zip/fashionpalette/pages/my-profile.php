<?php
global $pro_dir, $user_id, $data;


if (!is_logged_in()) {
    header('Location: ' . $pro_dir . 'login');
    exit();
}

fetch_profile();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['profile-update'])) {
        update_profile();
    }
    if (isset($_POST['contact-update'])) {
        update_contact();
    }
    if (isset($_POST['password-update'])) {
        update_password();
    }
}

function update_profile()
{
    global $user_id;

    $conn = connect_db();
    $first_name = htmlspecialchars(trim($_POST['first-name']));
    $last_name = htmlspecialchars(trim($_POST['last-name']));

    // Write the SQL statement to fetch my orders
    $sql = "UPDATE `user` SET first_name = ?, last_name = ? WHERE user_id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssi', $first_name, $last_name, $user_id);

    // Execute the statement
    if ($stmt->execute()) {
        $_SESSION['form_data'] = ['message' => 'Successfully updated user profile'];
    } else {
        $_SESSION['form_data'] = ['error' => 'Error while updating user profile: ' . $stmt->error];
    }

    header("Location: " . $_SERVER["REQUEST_URI"]);
    exit();
}

function update_contact()
{
    global $user_id;

    $conn = connect_db();
    // Start transaction
    $conn->begin_transaction();

    try {
        $contact_name = htmlspecialchars(trim($_POST['contact-name']));
        $contact_no = htmlspecialchars(trim($_POST['contact-no']));
        $address_line_one = htmlspecialchars(trim($_POST['address-line-one']));
        $address_line_two = htmlspecialchars(trim($_POST['address-line-two']));
        $city = htmlspecialchars(trim($_POST['city']));
        $state = htmlspecialchars(trim($_POST['state']));
        $postal_code = htmlspecialchars(trim($_POST['postal-code']));

        // Insert or update contact info
        $sql = "INSERT INTO `contact` (
                user_id, contact_name, contact_no, address_line_one, address_line_two, city, state, postal_code)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE user_id = VALUES(user_id)";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param('isssssss', $user_id, $contact_name, $contact_no, $address_line_one,
            $address_line_two, $city, $state, $postal_code);

        if (!$stmt->execute()) {
            throw new Exception("Failed to update shipping contact: " . $stmt->error);
        }

        $contact_id = $stmt->insert_id;
        $sql = "UPDATE `user` SET shipping_id = ?, billing_id = ? WHERE user_id = ?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param('iii', $contact_id, $contact_id, $user_id);

        if (!$stmt->execute()) {
            throw new Exception("Failed to update user: " . $stmt->error);
        }

        // Commit the transaction
        $conn->commit();
        $conn->close();

        $_SESSION['form_data'] = ['message' => 'Successfully updated shipping contact'];
        // Redirect back to the form page
        header("Location: " . $_SERVER["REQUEST_URI"]);
    } catch (Exception $e) {
        // Rollback the transaction if any query failed
        $conn->rollback();
        $_SESSION['form_data'] = [
            'error' => 'Error while updating user profile: ' . $e->getMessage(),
            'contact_name' => $_POST['contact-name'],
            'contact_no' => $_POST['contact-no'],
            'address_line_one' => $_POST['address-line-one'],
            'address_line_two' => $_POST['address-line-two'],
            'city' => $_POST['city'],
            'state' => $_POST['state'],
            'postal_code' => $_POST['postal-code'],
        ];
        // Redirect back to the form page
        header("Location: " . $_SERVER["REQUEST_URI"]);
        // Close the database connection
        $conn->close();
    }
}

function update_password()
{
    global $user_id;

    $conn = connect_db();
    $current_password = htmlspecialchars(trim($_POST['current-password']));
    $new_password = htmlspecialchars(trim($_POST['new-password']));

    $stmt = $conn->prepare("SELECT * FROM user WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);

    if (!$stmt->execute()) {
        $_SESSION['form_data'] = ['error' => 'Error while updating user password: ' . $stmt->error];
        header("Location: " . $_SERVER["REQUEST_URI"]);
        exit();
    }

    $user = $stmt->get_result()->fetch_assoc();
    if (!password_verify($current_password, $user["password"])) {
        $_SESSION['form_data'] = ['error' => 'Current password does not match: ' . $stmt->error];
        header("Location: " . $_SERVER["REQUEST_URI"]);
        exit();
    }

    // Hash password
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    // Write the SQL statement to fetch my orders
    $sql = "UPDATE `user` SET password = ? WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('si', $hashed_password, $user_id);

    // Execute the statement
    if ($stmt->execute()) {
        $_SESSION['form_data'] = ['message' => 'Successfully updated user profile'];
    } else {
        $_SESSION['form_data'] = ['error' => 'Error while updating user profile: ' . $stmt->error];
    }

    header("Location: " . $_SERVER["REQUEST_URI"]);
    exit();
}

function fetch_profile()
{
    global $data, $user_id;

    $conn = connect_db();
    // Write the SQL statement to fetch my orders
    $sql = "SELECT * FROM `user` as u LEFT JOIN `contact` as c on c.contact_id = u.billing_id WHERE u.user_id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $user_id);

    // Execute the statement
    if (!$stmt->execute()) {
        $_SESSION['form_data'] = ['error' => 'Error while retrieving user profile: ' . $stmt->error];
        $stmt->close();
        $conn->close();
        header("Location: " . $_SERVER["REQUEST_URI"]);
        exit();
    }

    $data = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $conn->close();
}

?>

<div class="container custom-container custom-container-md p-5">
    <form class="container px-3" action="" method="POST">
        <div class="form-sub-title text-content">MY PROFILE</div>
        <div class="row">
            <div class="col form-group required pr-1">
                <div class="input-wrapper">
                    <label for="first-name" class="form-label control-label">First Name</label>
                    <input id="first-name" name="first-name" type="text"
                           class="form-control" placeholder="First Name" required
                           value="<?php echo get_form_val("first_name"); ?>">
                </div>
            </div>
            <div class="col form-group required pl-1">
                <div class="input-wrapper">
                    <label for="last-name" class="form-label control-label">Last Name</label>
                    <input id="last-name" name="last-name" type="text"
                           class="form-control" placeholder="Last Name" required
                           value="<?php echo get_form_val("last_name") ?>">
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="input-wrapper">
                <label for="email" class="form-label control-label">User Email</label>
                <input id="email" name="email" type="email" class="form-control"
                       placeholder="Email" autocomplete="username" readonly
                       value="<?php echo get_form_val('email') ?>">
            </div>
        </div>
        <button name="profile-update" type="submit" class="btn btn-sm btn-custom-primary mt-2">
            Update Profile
        </button>
    </form>
    <form class="container my-5 px-3" method="POST">
        <div class="form-sub-title text-content">SHIPPING CONTACT</div>
        <div class="row">
            <div class="col-7 form-group required pr-1">
                <div class="input-wrapper">
                    <label for="contact-name" class="form-label control-label">Contact Name</label>
                    <input id="contact-name" name="contact-name" type="text" class="form-control"
                           placeholder="Contact Name" required
                           value="<?php echo get_form_val('contact_name') ?>">
                </div>
            </div>
            <div class="col-5 form-group required pl-1">
                <div class="input-wrapper">
                    <label for="contact-no" class="form-label control-label">Contact No</label>
                    <input id="contact-no" name="contact-no" type="text" class="form-control"
                           placeholder="Contact No" required
                           value="<?php echo get_form_val('contact_no') ?>">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-6 form-group required pr-1">
                <div class="input-wrapper">
                    <label for="address-line-one" class="form-label control-label">Address Line 1</label>
                    <input id="address-line-one" name="address-line-one" type="text" class="form-control"
                           placeholder="Address Line 1" required
                           value="<?php echo get_form_val('address_line_one') ?>">
                </div>
            </div>
            <div class="col-6 form-group pl-1">
                <div class="input-wrapper">
                    <label for="address-line-two" class="form-label control-label">Address Line 2</label>
                    <input id="address-line-two" name="address-line-two" type="text" class="form-control"
                           placeholder="Address Line 2"
                           value="<?php echo get_form_val('address_line_two') ?>">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col form-group required pr-1">
                <div class="input-wrapper">
                    <label for="city" class="form-label control-label">City</label>
                    <input id="city" name="city" type="text" class="form-control"
                           placeholder="City" required
                           value="<?php echo get_form_val('city') ?>">
                </div>
            </div>
            <div class="col form-group required px-1">
                <div class="input-wrapper">
                    <label for="state" class="form-label control-label">State</label>
                    <input id="state" name="state" type="text" class="form-control"
                           placeholder="State" required
                           value="<?php echo get_form_val('state') ?>">
                </div>
            </div>
            <div class="col form-group required pl-1">
                <div class="input-wrapper">
                    <label for="postal-code" class="form-label control-label">Postal Code</label>
                    <input id="postal-code" name="postal-code" type="text" class="form-control"
                           placeholder="Postal Code" required
                           value="<?php echo get_form_val('postal_code') ?>">
                </div>
            </div>
        </div>
        <button name="contact-update" type="submit" class="btn btn-sm btn-custom-primary mt-2">
            Update Shipping Contact
        </button>
    </form>
    <form class="container my-5 px-3" action="" method="POST">
        <div class="form-sub-title text-content">CHANGE PASSWORD</div>
        <div class="form-group required">
            <div class="input-wrapper">
                <label for="current-password" class="form-label control-label">Current Password</label>
                <input id="current-password" name="current-password" type="password" class="form-control"
                       placeholder="Current Password" autocomplete="new-password" required>
            </div>
        </div>
        <div class="form-group required">
            <div class="input-wrapper">
                <label for="new-password" class="form-label control-label">New Password</label>
                <input id="new-password" name="new-password" type="password" class="form-control"
                       placeholder="New Password" autocomplete="new-password" required>
            </div>
        </div>
        <button name="password-update" type="submit" class="btn btn-sm btn-custom-primary mt-2">
            Update password
        </button>
    </form>
</div>

