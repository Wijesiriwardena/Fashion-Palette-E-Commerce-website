<?php
global $pro_dir, $data;

$sort_options = get_sort_options();
$color_options = get_color_options();
$skin_tone_options = get_skintone_options();
$price_range_options = get_price_range_options();
$discount_options = get_discount_options();

$brands = get_brand_options();
$result = query_products();

function prep_where_clause()
{
    global $data;
    $queries = array();
    parse_str($_SERVER['QUERY_STRING'], $queries);

    $where_clause = null;
    if (isset($queries['search_text'])) {
        $where_clause = 'p.product_name LIKE \'%' . $queries['search_text'] . '%\' OR ' .
            'p.description LIKE \'%' . $queries['search_text'] . '%\'';
        $data['search_text'] = $queries['search_text'];
    } else {
        $data['search_text'] = null;
    }

    if (isset($queries['gender_id'])) {
        $gender_clause = 'p.gender_id = ' . intval($queries['gender_id']);
        $where_clause = isset($where_clause) ? $where_clause . ' AND ' . $gender_clause : $gender_clause;
    }

    if (isset($queries['category_id'])) {
        $category_clause = 'p.category_id = ' . intval($queries['category_id']);
        $where_clause = isset($where_clause) ? $where_clause . ' AND ' . $category_clause : $category_clause;
    }

    if (isset($queries['brand_id'])) {
        $brand_clause = 'p.brand_id = ' . intval($queries['brand_id']);
        $where_clause = isset($where_clause) ? $where_clause . ' AND ' . $brand_clause : $brand_clause;
        $data['brand_id'] = intval($queries['brand_id']);
    } else {
        $data['brand_id'] = null;
    }

    if (isset($queries['skin_tone'])) {
        $skin_tone_clause = 'p.skin_tone = \'' . $queries['skin_tone'] . '\'';
        $where_clause = isset($where_clause) ? $where_clause . ' AND ' . $skin_tone_clause : $skin_tone_clause;
        $data['skin_tone'] = $queries['skin_tone'];
    } else {
        $data['skin_tone'] = null;
    }

    if (isset($queries['price'])) {
        $price_clause = match ($queries['price']) {
            '1' => 'p.price <= 10',
            '2' => 'p.price <= 50 AND p.price > 10',
            '3' => 'p.price <= 250 AND p.price > 50',
            '4' => 'p.price <= 1000 AND p.price > 250',
            default => 'p.price > 1000',
        };
        $where_clause = isset($where_clause) ? $where_clause . ' AND ' . $price_clause : $price_clause;
        $data['price'] = $queries['price'];
    } else {
        $data['price'] = null;
    }

    if (isset($queries['discount'])) {
        $discount_clause = match ($queries['discount']) {
            '1' => 'p.discount <= 10',
            '2' => 'p.discount <= 20 AND p.discount > 10',
            '3' => 'p.discount <= 30 AND p.discount > 20',
            '4' => 'p.discount <= 40 AND p.discount > 30',
            default => 'p.discount > 50',
        };
        $where_clause = isset($where_clause) ? $where_clause . ' AND ' . $discount_clause : $discount_clause;
        $data['discount'] = $queries['discount'];
    } else {
        $data['discount'] = null;
    }

    return $where_clause;
}

function prep_order_clause()
{
    global $data;
    $queries = array();
    parse_str($_SERVER['QUERY_STRING'], $queries);

    $order_clause = " ORDER BY p.created_at DESC";
    if (isset($queries['sort'])) {
        $order_clause = ' ORDER BY p.price ';
        $order_clause = $queries['sort'] == '1' ? $order_clause . 'ASC' : $order_clause . 'DESC';
        $data['sort'] = $queries['sort'];
    } else {
        $data['sort'] = null;
    }
    return $order_clause;
}

function query_products()
{
    $conn = connect_db();
    $order_clause = prep_order_clause();
    $where_clause = prep_where_clause();

    $sql = "SELECT p.product_id, p.product_name, p.description, p.price, p.favourite_count, 
        p.image, b.brand_name as brand
        FROM product as p
        LEFT JOIN brand as b on p.brand_id = b.brand_id ";

    $sql = isset($where_clause) ? $sql . "WHERE " . $where_clause : $sql;
    $sql = $sql . $order_clause;

    $stmt = $conn->prepare($sql);

    // Execute the statement
    if (!$stmt->execute()) {
        $stmt->close();
        $conn->close();
        $_SESSION['form_data'] = ['error' => 'Error while retrieving products: ' . $stmt->error];
        echo $stmt->error;
        header("Location: " . $_SERVER["REQUEST_URI"]);
        exit();
    }

    $data = $stmt->get_result();
    $stmt->close();
    $conn->close();

    return $data;
}

?>

<nav id="filters-navbar" class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <div class="row" style="width: 100%">
            <div class="col-lg-2 col-sm-4 form-group mb-0">
                <label for="sort" class="form-label control-label filter-label">Sort</label>
                <select id="sort" name="sort" class="custom-select <?php if (isset($data['sort'])) {
                    echo 'custom-selected';
                } ?>">
                    <?php foreach ($sort_options as $skin_tone_option) : ?>
                        <option value="<?php echo $skin_tone_option['value'] ?>"
                            <?php if (isset($skin_tone_option['value']) && isset($data['sort']) &&
                                $data['sort'] === $skin_tone_option['value']) {
                                echo 'selected';
                            } ?>>
                            <?php echo $skin_tone_option['name'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-lg-2 col-sm-4 form-group mb-0">
                <label for="brand_id" class="form-label control-label filter-label">Brand</label>
                <select id="brand_id" name="brand_id" class="custom-select <?php if (isset($data['brand_id'])) {
                    echo 'custom-selected';
                } ?>">
                    <option value="all">All Brands</option>
                    <?php foreach ($brands as $brand) : ?>
                        <option value="<?php echo $brand['brand_id'] ?>"
                            <?php if (isset($data['brand_id']) && isset($brand['brand_id']) &&
                                $data['brand_id'] === $brand['brand_id']) {
                                echo 'selected';
                            } ?>>
                            <?php echo $brand['brand_name'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-lg-2 col-sm-4 form-group mb-0">
                <label for="price" class="form-label control-label filter-label">Price range</label>
                <select id="price" name="price" class="custom-select <?php if (isset($data['price'])) {
                    echo 'custom-selected';
                } ?>">
                    <?php foreach ($price_range_options as $price_range_option) : ?>
                        <option value="<?php echo $price_range_option['value'] ?>"
                            <?php if (isset($price_range_option['value']) && isset($data['price']) &&
                                $data['price'] === $price_range_option['value']) {
                                echo 'selected';
                            } ?>>
                            <?php echo $price_range_option['name'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-lg-2 col-sm-4 form-group mb-0">
                <label for="discount" class="form-label control-label filter-label">Discount %</label>
                <select id="discount" name="discount" class="custom-select <?php if (isset($data['discount'])) {
                    echo 'custom-selected';
                } ?>">
                    <?php foreach ($discount_options as $discount_option) : ?>
                        <option value="<?php echo $discount_option['value'] ?>"
                            <?php if (isset($discount_option['value']) && isset($data['discount']) &&
                                $data['discount'] === $discount_option['value']) {
                                echo 'selected';
                            } ?>>
                            <?php echo $discount_option['name'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-lg-2 col-sm-4 form-group mb-0">
                <label for="skin_tone" class="form-label control-label filter-label">Skin Tone</label>
                <select id="skin_tone" name="skin_tone" class="custom-select <?php if (isset($data['skin_tone'])) {
                    echo 'custom-selected';
                } ?>">
                    <option value="all">All Skin Tones</option>
                    <?php foreach ($skin_tone_options as $skin_tone_option) : ?>
                        <option value="<?php echo $skin_tone_option['value'] ?>"
                            <?php $val = get_form_val('skin_tone');
                            if (isset($val) && isset($data['skin_tone']) && $val === $skin_tone_option['value']) {
                                echo 'selected';
                            } ?>>
                            <?php echo $skin_tone_option['name'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    </div>
</nav>

<?php if ($result->num_rows > 0) {
    include_once __DIR__ . '/../includes/product.php';
    // Loop through the products and render product card
    $products = $result->fetch_all(MYSQLI_ASSOC);
    ?>
    <div class="container my-5">
        <div class="row" style="width: 100%">
            <?php foreach ($products as $product): ?>
                <div class="col-lg-3 col-md-4 col-sm-12">
                    <?php echo product_card_view($product); ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php } else {
    include_once __DIR__ . '/../includes/not-found.php';
} ?>

<script>
    let _lastScroll = window.scrollY;
    window.addEventListener("scroll", function () {
        const currentScroll = window.scrollY;
        if (Math.abs(currentScroll - _lastScroll) < 100) {
            return;
        }
        if (currentScroll < _lastScroll) {
            if (document.getElementById("filters-navbar")) {
                document.getElementById("filters-navbar").style.top = '90px';
            }
        } else {
            if (document.getElementById("filters-navbar")) {
                document.getElementById("filters-navbar").style.top = '-100px';
            }
        }
        _lastScroll = currentScroll;
    });

    document.getElementById("sort").addEventListener("change", function () {
        fetch_products("sort");
    });

    // document.getElementById("color_id").addEventListener("change", function () {
    //     fetch_products("color");
    // });

    document.getElementById("skin_tone").addEventListener("change", function () {
        fetch_products("skin_tone");
    });

    document.getElementById("brand_id").addEventListener("change", function () {
        fetch_products("brand_id");
    });

    document.getElementById("price").addEventListener("change", function () {
        fetch_products("price");
    });

    document.getElementById("discount").addEventListener("change", function () {
        fetch_products("discount");
    });

    function fetch_products(identifier) {
        const value = document.getElementById(identifier).value;
        const xhr = new XMLHttpRequest();
        xhr.open('GET', window.location.href, true);
        xhr.onreadystatechange = function () {
            const searchParams = new URLSearchParams(window.location.search);
            if (value !== "all") {
                searchParams.set(identifier, value);
            } else {
                searchParams.delete(identifier);
            }
            window.location.search = searchParams.toString();
        };
        xhr.send();
    }
</script>


